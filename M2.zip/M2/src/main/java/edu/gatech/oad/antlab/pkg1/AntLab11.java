package edu.gatech.oad.antlab.pkg1;



/** 
 * CS2340 Ant Lab
 *
 * AntLab11.java helper class
 * @author Robert
 * @version 1.0
 */
 public class AntLab11 {
    
    
   /**
    * retrieves a pre-stored string message
    * @return the string
    */
    public String getMessage() {
        return "Congrats!";
    }
    
 } 