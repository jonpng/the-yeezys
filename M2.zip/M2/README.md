# the-yeezys
Hi, something will be here later.

To run tasks in the gradle files, you gotta do:
```
gradle -b <file.gradle> <task>
```
