Name:Steve Nkuranga
Email:snkuranga8@gatech.edu