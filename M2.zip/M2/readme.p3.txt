Jonathan Duong
jduong6@gatech.edu