Taylor Havrilak
thavrilak3@gatech.edu